# CreatedProcessId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processId** | **int** | Id of the process created | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


