# GetProcesses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processes** | [**\SendinBlue\Client\Model\GetProcess[]**](GetProcess.md) | List of processes available on your account | [optional] 
**count** | **int** | Number of processes available on your account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


