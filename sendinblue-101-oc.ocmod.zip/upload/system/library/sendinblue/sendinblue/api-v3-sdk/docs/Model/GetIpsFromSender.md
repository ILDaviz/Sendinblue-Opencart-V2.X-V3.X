# GetIpsFromSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ips** | [**\SendinBlue\Client\Model\GetIpFromSender[]**](GetIpFromSender.md) | Dedicated IP(s) linked to a sender | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


