# GetChildInfoStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**previousMonthTotalSent** | **int** | Overall emails sent for the previous month | [optional] 
**currentMonthTotalSent** | **int** | Overall emails sent for current month | [optional] 
**totalSent** | **int** | Overall emails sent for since the account exists | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


