# GetAccountRelayData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userName** | **string** | Email to use as login on SMTP | 
**relay** | **string** | URL of the SMTP Relay | 
**port** | **int** | Port used for SMTP Relay | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


