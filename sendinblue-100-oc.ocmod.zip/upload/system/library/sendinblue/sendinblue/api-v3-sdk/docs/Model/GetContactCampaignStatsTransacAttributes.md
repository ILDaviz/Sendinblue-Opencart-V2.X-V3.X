# GetContactCampaignStatsTransacAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderDate** | [**\DateTime**] | Date of the order | 
**orderPrice** | **float** | Price of the order | 
**orderId** | **int** | ID of the order | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


