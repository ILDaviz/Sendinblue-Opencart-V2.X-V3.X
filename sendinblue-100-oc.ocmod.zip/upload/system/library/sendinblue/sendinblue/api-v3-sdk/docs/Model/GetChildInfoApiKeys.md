# GetChildInfoApiKeys

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**v2** | [**\SendinBlue\Client\Model\GetChildInfoApiKeysV2[]**](GetChildInfoApiKeysV2.md) |  | 
**v3** | [**\SendinBlue\Client\Model\GetChildInfoApiKeysV3[]**](GetChildInfoApiKeysV3.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


