# SendTestSms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumbers** | **string[]** | Mobile number with the country code to send test SMS. The mobile number defined here must belong to one of your contacts in SendinBlue account and must not be blacklisted | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


