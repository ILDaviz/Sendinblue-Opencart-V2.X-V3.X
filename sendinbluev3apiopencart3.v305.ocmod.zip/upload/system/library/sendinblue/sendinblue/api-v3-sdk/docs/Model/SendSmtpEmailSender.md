# SendSmtpEmailSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Name of the sender from which the emails will be sent | [optional] 
**email** | **string** | Email of the sender from which the emails will be sent | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


