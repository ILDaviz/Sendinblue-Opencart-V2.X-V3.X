# UpdateList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Name of the list. Either of the two parameters (name, folderId) can be updated at a time. | [optional] 
**folderId** | **int** | Id of the folder in which the list is to be moved. Either of the two parameters (name, folderId) can be updated at a time. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


